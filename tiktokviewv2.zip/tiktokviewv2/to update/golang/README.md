Zefoy bot in golang 70% finished (faster)  
